console.log("Normal log message - .log()");
console.info("Informational message  - .info()");
console.warn("Warning message - .warn()");
console.error("Error message - .error()");

console.table([
  { name: "Atharv", age: 25 },
  { name: "Bobby", age: 30 }
]);